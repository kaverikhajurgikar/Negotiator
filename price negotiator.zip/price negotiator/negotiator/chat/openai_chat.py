import os
import openai

def chat_with_gpt(prompt, all_messages, grand_total):
    # Predefined responses (case-insensitive lookup)
    predefined_prompts = {
        "did openai make you?": "Yes, I was created by OpenAI and based on the GPT model."
    }

    lower_prompt = prompt.lower()
    if lower_prompt in predefined_prompts:
        return predefined_prompts[lower_prompt]

    # Prepare conversation history for context
    try:
        context = '\n--'.join([f"{msg.sender}: {msg.content}" for msg in all_messages])
    except AttributeError:
        return "Error: Message objects must have 'sender' and 'content' attributes."

    # Calculate max discounted price
    try:
        grand_total = float(grand_total)
        max_discounted_price = round(grand_total * 0.7, 2)
    except ValueError:
        return "Error: grand_total must be a valid number."

    # Define the prompt
    formatted_prompt = f"""
    You are a chatbot helping with price negotiations.
    The total price is {grand_total}, and the maximum discounted price is {max_discounted_price}.
    Here is the conversation so far:
    {context}

    User: {prompt}
    Chatbot:
    """

    # OpenAI API call
    try:
        client = openai.OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are an expert negotiation assistant."},
                {"role": "user", "content": formatted_prompt},
            ],
        )
        return response.choices[0].message.content
    except openai.OpenAIError as e:
        return f"Error communicating with OpenAI: {str(e)}"
    except Exception as e:
        return f"Unexpected error: {str(e)}"
